import api from './api';

export async function criarConteudos(dados) {
  const { data } = await api.post('conteudos', dados);
  return data;
}

export async function getListaConteudos() {
    const { data } = await api.get('conteudos');
    return data;
}
